package com.example.tugas_login_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
